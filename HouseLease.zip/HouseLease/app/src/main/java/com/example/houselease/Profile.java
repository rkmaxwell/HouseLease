package com.example.houselease;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Profile extends AppCompatActivity {

    private EditText name,email,location;
    private Button updateButton;
    private ImageView imageViewChooseImage;

    String userMail;
    int sid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        name=(EditText)findViewById(R.id.profileName);
        email=(EditText)findViewById(R.id.profileMail);
        location=(EditText)findViewById(R.id.profileLocation);
        imageViewChooseImage=(ImageView)findViewById(R.id.profilePhoto);
        updateButton=(Button)findViewById(R.id.btnUpdateProfile);

        location.requestFocus();

        if(!SharedPrefManager.getInstance(Profile.this).isLoggedIn()){
            startActivity(new Intent(Profile.this,Login.class));
        }else{

            User user=SharedPrefManager.getInstance(Profile.this).getUser();

            userMail=user.getEmail();
            sid=user.getId();

        }

        loadUserDetail();
    }


    private void loadUserDetail(){

        location.requestFocus();
        email.setFocusable(false);
        final  String URLUser="http://192.168.43.182/rentals/profile.php";
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URLUser, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                //Toast.makeText(Profile.this, response, Toast.LENGTH_LONG).show();

                try {

                    JSONArray users = new JSONArray(response);

                    for (int i = 0; i < users.length(); i++) {
                        JSONObject userObject = users.getJSONObject(i);

                        int id=userObject.getInt("id");
                        String userName=userObject.getString("name");
                        String userEmail=userObject.getString("email");

                        name.setText(userName);
                        email.setText(userEmail);


                    }

                }
                catch (Exception e){
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(Profile.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params=new HashMap<>();

                String userID=String.format("%s",sid);
                params.put("sid",userID);

                return  params;
            }
        };

        Volley.newRequestQueue(Profile.this).add(stringRequest);
    }

    private void getLocation(){

        String locale=location.getText().toString().trim();

        if(TextUtils.isEmpty(locale)){

            location.setError("Please give us your current location");
            location.requestFocus();
        }else{


        }

    }
}
