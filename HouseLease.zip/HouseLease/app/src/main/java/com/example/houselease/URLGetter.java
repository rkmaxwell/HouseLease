package com.example.houselease;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class URLGetter extends AppCompatActivity {

    String a,b,c;
    String URLsort;
    RecyclerView recyclerView;
    List<House> list;
    SearchedAdapter searchedAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_urlgetter);

        list=new ArrayList<>();
        recyclerView=(RecyclerView)findViewById(R.id.recyclerViewMoreSearch);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Bundle bundle=getIntent().getExtras();
        if(bundle!=null){
            a=bundle.getString("q");

            switch (a) {
                case "nairobi":
                    Toast.makeText(URLGetter.this, "nairobi", Toast.LENGTH_SHORT).show();
                    URLsort="http://192.168.43.182/rentals/placesearch.php?place="+a;
                    loadHouses();
                    break;
                case "nyeri":
                    Toast.makeText(URLGetter.this, "Nyeri", Toast.LENGTH_SHORT).show();
                    URLsort="http://192.168.43.182/rentals/placesearch.php?place="+a;
                    loadHouses();
                    break;
                default:

                    Toast.makeText(URLGetter.this, "Other", Toast.LENGTH_SHORT).show();
                    break;
            }

        }
    }

    private void loadHouses(){

        StringRequest stringRequest=new StringRequest(Request.Method.GET, URLsort, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {

                    Toast.makeText(URLGetter.this, response, Toast.LENGTH_SHORT).show();
                    JSONArray houses = new JSONArray(response);

                    for (int i = 0; i < houses.length(); i++) {
                        JSONObject houseObject = houses.getJSONObject(i);

                        int id = houseObject.getInt("id");
                        String name = houseObject.getString("name");
                        String category = houseObject.getString("category");
                        String description = houseObject.getString("description");
                        double price = houseObject.getDouble("price");
                        String image = houseObject.getString("photo");
                        String location = houseObject.getString("location");
                        String landlord = houseObject.getString("landlord");
                        double rate = houseObject.getDouble("rate");


                        //String place=houseObject.getString("location");

                        String imagePath = "http://192.168.43.182/asammy/uploads/" + image;
                        String path = "http://leaseholder.mabnets.com/android/uploads/" + image;

                        // Toast.makeText(HouseFilter.this, imagePath, Toast.LENGTH_SHORT).show();

                        House house = new House(id, name,category, description, location, rate, price, imagePath,landlord);
                        Toast.makeText(URLGetter.this, response, Toast.LENGTH_SHORT).show();
                        list.add(house);
                        searchedAdapter=new SearchedAdapter(URLGetter.this,list);
                        recyclerView.setAdapter(searchedAdapter);


                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(URLGetter.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        });

        Volley.newRequestQueue(URLGetter.this).add(stringRequest);
    }
}
