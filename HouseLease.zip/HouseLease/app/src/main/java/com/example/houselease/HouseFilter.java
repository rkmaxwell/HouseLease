package com.example.houselease;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class HouseFilter extends AppCompatActivity {

    RecyclerView recyclerViewSa;
    Button sender,buttonGetNear,buttonGetNairobi,buttonGetNakuru,buttonGetNyeri;
    EditText searchField;

    SearchedAdapter adapter;
    List<House> houseList;
    String q;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_house_filter);

        houseList=new ArrayList<>();
        recyclerViewSa=(RecyclerView)findViewById(R.id.recyclerViewSearch);
        recyclerViewSa.setHasFixedSize(true);
        recyclerViewSa.setLayoutManager(new LinearLayoutManager(this));

        searchField=(EditText)findViewById(R.id.etSearch);
        sender=(Button)findViewById(R.id.buttonSearch);

        buttonGetNear=(Button)findViewById(R.id.buttonNear);
        buttonGetNairobi=(Button)findViewById(R.id.buttonNairobi);
        buttonGetNakuru=(Button)findViewById(R.id.buttonNyeri);

        sender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadSearchedHouses();
            }
        });
        buttonGetNairobi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q="nairobi";

                Bundle bundle=new Bundle();
                bundle.putString("q",q);
                Intent intent=new Intent(HouseFilter.this,URLGetter.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        buttonGetNakuru.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q="nyeri";

                Bundle bundle=new Bundle();
                bundle.putString("q",q);
                Intent intent=new Intent(HouseFilter.this,URLGetter.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }

    public  void loadSearchedHouses(){

        final String q=searchField.getText().toString().trim();
        final  String URLSearch="http://192.168.43.182/rentals/search.php?house="+q;

        if(q.length()>1){

            StringRequest stringRequest=new StringRequest(Request.Method.GET, URLSearch, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    //Toast.makeText(HouseFilter.this, response, Toast.LENGTH_SHORT).show();
                    if(response.equals("Sorry, your search was not found")){
                        Toast.makeText(HouseFilter.this, "Sorry, search for "+ q +" was not found", Toast.LENGTH_SHORT).show();

                    }else {

                        try {

                            JSONArray houses = new JSONArray(response);

                            for (int i = 0; i < houses.length(); i++) {
                                JSONObject houseObject = houses.getJSONObject(i);

                                int id = houseObject.getInt("id");
                                String name = houseObject.getString("name");
                                String category = houseObject.getString("category");
                                String description = houseObject.getString("description");
                                double price = houseObject.getDouble("price");
                                String image = houseObject.getString("photo");
                                String location = houseObject.getString("location");
                                String landlord = houseObject.getString("landlord");
                                double rate = houseObject.getDouble("rate");


                                //String place=houseObject.getString("location");

                                String imagePath = "http://192.168.101.1/asammy/uploads/" + image;
                                String path = "http://leaseholder.mabnets.com/android/uploads/" + image;

                                // Toast.makeText(HouseFilter.this, imagePath, Toast.LENGTH_SHORT).show();

                                House house = new House(id, name,category, description, location, rate, price, imagePath,landlord);
                                houseList.add(house);
                                adapter = new SearchedAdapter(HouseFilter.this, houseList);
                                recyclerViewSa.setAdapter(adapter);


                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }, new Response.ErrorListener()

            {
                @Override
                public void onErrorResponse (VolleyError error){
                    Toast.makeText(HouseFilter.this, error.toString(), Toast.LENGTH_SHORT).show();
                }

            });

            Volley.newRequestQueue(HouseFilter.this).add(stringRequest);

        }else{

            searchField.requestFocus();
        }

    }

}
