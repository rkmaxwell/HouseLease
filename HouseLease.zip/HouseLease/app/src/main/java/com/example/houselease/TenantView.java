package com.example.houselease;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TenantView extends AppCompatActivity {

    String path;
    RecyclerView recyclerViewOccupants;
    List<Tenant> tenantList;
    TenantAdapter tenantAdapter;
    String email;int sid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tenant_view);


        if(!SharePrefLandlordManager.getInstance(TenantView.this).isLoggedIn()){
            startActivity(new Intent(TenantView.this,LandlordLogin.class));

        }else{

            Landlord landlord=SharePrefLandlordManager.getInstance(TenantView.this).getLandlord();
            email=landlord.getEmail();
            sid=landlord.getId();
        }
        tenantList=new ArrayList<>();
        recyclerViewOccupants=(RecyclerView)findViewById(R.id.recyclerViewTenant);
        recyclerViewOccupants.setHasFixedSize(true);
        recyclerViewOccupants.setLayoutManager(new LinearLayoutManager(this));


        getMyTenants();
    }

    private void getMyTenants(){

        final String URLTenants="http:192.168.43.182/rentals/get_tenants.php?sid="+sid;


        StringRequest stringRequest=new StringRequest(Request.Method.GET, URLTenants, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {


                try {

                    JSONArray tenant = new JSONArray(response);

                    for(int i=0;i<tenant.length();i++){

                        JSONObject tenants=tenant.getJSONObject(i);

                        int id=tenants.getInt("id");
                        int room=tenants.getInt("room");
                        String name=tenants.getString("tenant");
                        String phone=tenants.getString("phone");
                        String profile=tenants.getString("profile");

                        double payment=tenants.getDouble("payment");
                        double balance=tenants.getDouble("balance");
                        if(profile.equals("null")){
                            path="http://192.168.43.182/rentals/uploads/user.png";

                        }else{
                            path="http://192.168.43.182/rentals/profile/"+profile;

                        }

                        Toast.makeText(TenantView.this, profile, Toast.LENGTH_SHORT).show();
                        Tenant myTenant=new Tenant(id,room,name,phone,path,payment,balance);
                        tenantList.add(myTenant);
                        tenantAdapter=new TenantAdapter(TenantView.this,tenantList);
                        recyclerViewOccupants.setAdapter(tenantAdapter);



                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(TenantView.this, error.toString(), Toast.LENGTH_SHORT).show();
            }

        });

        Volley.newRequestQueue(TenantView.this).add(stringRequest);
    }
}
