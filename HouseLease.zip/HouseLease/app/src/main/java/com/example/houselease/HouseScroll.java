package com.example.houselease;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import com.smarteist.autoimageslider.DefaultSliderView;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderLayout;
import com.smarteist.autoimageslider.SliderView;

public class HouseScroll extends AppCompatActivity {


    SliderLayout sliderLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_house_scroll);


        sliderLayout = (SliderLayout) findViewById(R.id.imageSlider);
        sliderLayout.setIndicatorAnimation(IndicatorAnimations.FILL);
        sliderLayout.setScrollTimeInSec(1);

        setSliderViews();
    }

    private void setSliderViews() {

        for (int i = 0; i <= 3; i++) {

            DefaultSliderView sliderView = new DefaultSliderView(this);

            switch (i) {
                case 0:
                    sliderView.setImageUrl("http://192.168.43.182/rentals/uploads/PROD-20190411-154011.jpg");
                    sliderView.setDescription("Amani Rentals, Nakuru");
                    break;
                case 1:
                    sliderView.setImageUrl("http://192.168.43.182/rentals/uploads/PROD-20190411-154011.jpg");
                    break;
                case 2:
                    sliderView.setImageUrl("http://192.168.43.182/rentals/uploads/PROD-20190411-154011.jpg");
                    break;
                case 3:
                    sliderView.setImageUrl("http://192.168.43.182/rentals/uploads/PROD-20190411-154011.jpg");
                    break;
            }

            sliderView.setImageScaleType(ImageView.ScaleType.CENTER_CROP);
            sliderView.setDescription("setDescription " + (i + 1));
            final int finalI = i;
            sliderView.setOnSliderClickListener(new SliderView.OnSliderClickListener() {
                @Override
                public void onSliderClick(SliderView sliderView) {
                    Toast.makeText(HouseScroll.this, "This is slider " + (finalI + 1), Toast.LENGTH_SHORT).show();
                }
            });

            //at last add this view in your layout :
            sliderLayout.addSliderView(sliderView);
        }
    }
}
