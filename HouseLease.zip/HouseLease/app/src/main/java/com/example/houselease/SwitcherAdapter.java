package com.example.houselease;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import java.util.List;

public class SwitcherAdapter extends RecyclerView.Adapter<SwitcherAdapter.SwitcherViewHolder>{


    private Context mCtx;
    private List<House> list;

    public SwitcherAdapter(Context mCtx, List<House> list) {
        this.mCtx = mCtx;
        this.list = list;
    }

    @NonNull
    @Override
    public SwitcherViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        LayoutInflater layoutInflater=LayoutInflater.from(mCtx);
        View view= layoutInflater.inflate(R.layout.layout_switcher,null);
        return new SwitcherViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull SwitcherViewHolder switcherViewHolder, int i) {

        final  House house=list.get(i);

        Glide.with(mCtx)
                .load(house.getImage())
                .into(switcherViewHolder.imageView);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class SwitcherViewHolder extends RecyclerView.ViewHolder{

        ImageView imageView;
        public SwitcherViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView=(ImageView)itemView.findViewById(R.id.imageSwitch);
        }
    }
}
