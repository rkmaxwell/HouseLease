package com.example.houselease;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

public class LandlordAdapter extends RecyclerView.Adapter<LandlordAdapter.LandlordViewHolder> {


    private Context mCtx;
    private List<RegisteredLandlord> landlordList;

    public LandlordAdapter(Context mCtx, List<RegisteredLandlord> landlordList) {
        this.mCtx = mCtx;
        this.landlordList = landlordList;
    }

    @NonNull
    @Override
    public LandlordViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        LayoutInflater layoutInflater=LayoutInflater.from(mCtx);
        View view=layoutInflater.inflate(R.layout.landlord_layout,null);
        return new LandlordViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LandlordViewHolder landlordViewHolder, int i) {

        final RegisteredLandlord landlord=landlordList.get(i);
        landlordViewHolder.landlordName.setText(landlord.getName());
        landlordViewHolder.landlordAddress.setText(landlord.getAddress());
        landlordViewHolder.landlordContact.setText(landlord.getEmail());

        Glide.with(mCtx)
                .load(landlord.getProfile())
                .into(landlordViewHolder.imageLandlord);
    }

    @Override
    public int getItemCount() {
        return landlordList.size();
    }

    class LandlordViewHolder extends RecyclerView.ViewHolder{

         ImageView imageLandlord;
         TextView landlordName,landlordAddress,landlordContact,landlordHouse;

        public LandlordViewHolder(@NonNull View itemView) {
            super(itemView);

            imageLandlord=(ImageView)itemView.findViewById(R.id.imageViewLandlord);
            landlordName=(TextView)itemView.findViewById(R.id.tvLandlordName);
            landlordAddress=(TextView)itemView.findViewById(R.id.tvLandlordLocation);
            landlordContact=(TextView)itemView.findViewById(R.id.tvLandlordContact);
            landlordHouse=(TextView)itemView.findViewById(R.id.tvLandlordHouse);

        }
    }
}
