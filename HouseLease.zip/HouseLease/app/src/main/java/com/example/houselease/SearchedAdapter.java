package com.example.houselease;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

public class SearchedAdapter extends RecyclerView.Adapter<SearchedAdapter.SearchedHouseAdapter> {


    private Context mCtx;
    private List<House> list;

    public SearchedAdapter(Context mCtx, List<House> list) {
        this.mCtx = mCtx;
        this.list = list;
    }

    @NonNull
    @Override
    public SearchedHouseAdapter onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater=LayoutInflater.from(mCtx);
        View view=layoutInflater.inflate(R.layout.search_layout,null);
        SearchedHouseAdapter adapter=new SearchedHouseAdapter(view);
        return  adapter;

    }

    @Override
    public void onBindViewHolder(@NonNull SearchedHouseAdapter searchedHouseAdapter, int i) {

        final  House house=list.get(i);
        searchedHouseAdapter.textViewName.setText(house.getTittle());
        searchedHouseAdapter.textViewLocation.setText(house.getLocation());
        searchedHouseAdapter.textViewPrice.setText(String.format("%s",house.getPrice()));

        Glide.with(mCtx)
                .load(house.getImage())
                .into(searchedHouseAdapter.imageView);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class SearchedHouseAdapter extends RecyclerView.ViewHolder{

        ImageView imageView;
        TextView textViewName,textViewLocation,textViewPrice,textViewLandlord;
        public SearchedHouseAdapter(@NonNull View itemView) {
            super(itemView);

            imageView=itemView.findViewById(R.id.sImage);
            textViewName=itemView.findViewById(R.id.sName);
            textViewLocation=itemView.findViewById(R.id.sLocation);
            textViewPrice=itemView.findViewById(R.id.sPrice);
            textViewLandlord=itemView.findViewById(R.id.sLandlord);
        }
    }
}
