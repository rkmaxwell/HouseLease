package com.example.houselease;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.HashMap;

public class LandlordLogin extends AppCompatActivity {

    private EditText email,password;
    private Button buttonLogin;
    private ProgressBar progressBarLogin;

    final String urlLandLogin="http:/192.168.43.182/rentals/Api.php?apicall=loginlandlord";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landlord_login);

        email=(EditText)findViewById(R.id.landlordMail);
        password=(EditText)findViewById(R.id.landlordPassword);
        progressBarLogin=(ProgressBar)findViewById(R.id.LoginLandlordProgressBar);

        buttonLogin=(Button)findViewById(R.id.btnLandlordLogin);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                loginLandlord();
            }
        });
    }

    public void loginLandlord(){
        final String mail=email.getText().toString().trim();
        final String pass=password.getText().toString().trim();

        if(TextUtils.isEmpty(mail)){
            email.setError("Email is required");
            email.requestFocus();
        }else if(TextUtils.isEmpty(pass)){
            password.setError("Enter your password");
            password.requestFocus();
        }else {


            class LoginLand extends AsyncTask<Void,Void,String> {

                @Override
                protected void onPreExecute() {
                    super.onPreExecute();

                    progressBarLogin.setVisibility(View.VISIBLE);
                }

                @Override
                protected void onPostExecute(String s) {
                    super.onPostExecute(s);

                    progressBarLogin.setVisibility(View.GONE);

                    try{

                        JSONObject jsonObject=new JSONObject(s);

                        if(!jsonObject.getBoolean("error")){
                            Toast.makeText(getApplicationContext(), jsonObject.getString("message"), Toast.LENGTH_SHORT).show();

                            JSONObject  userJson=jsonObject.getJSONObject("user");

                            Landlord landlord=new Landlord(
                                    userJson.getInt("id"),
                                    userJson.getString("email")
                            );

                            SharePrefLandlordManager.getInstance(LandlordLogin.this).userLogin(landlord);

                            finish();
                            startActivity(new Intent(LandlordLogin.this,LandlordController.class));
                            Toast.makeText(LandlordLogin.this, landlord.getEmail(), Toast.LENGTH_SHORT).show();
                        }else{

                            Toast.makeText(LandlordLogin.this, "Incorrect username or password", Toast.LENGTH_SHORT).show();

                            Toast.makeText(LandlordLogin.this, jsonObject.getString("error"), Toast.LENGTH_SHORT).show();

                        }

                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }

                @Override
                protected String doInBackground(Void... voids) {

                    RequestHandler requestHandler=new RequestHandler();

                    HashMap<String,String> params=new HashMap<>();
                    params.put("email",mail);
                    params.put("pass",pass);

                    return requestHandler.sendPostRequest(urlLandLogin,params);
                }
            }

            LoginLand loginLand=new LoginLand();
            loginLand.execute();
        }
    }
}
