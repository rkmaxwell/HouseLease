package com.example.houselease;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

public class TenantAdapter extends RecyclerView.Adapter<TenantAdapter.TenantViewAdapter> {

    private Context mCtx;
    private List<Tenant> tenantList;

    public TenantAdapter(Context mCtx, List<Tenant> tenantList) {
        this.mCtx = mCtx;
        this.tenantList = tenantList;
    }

    @NonNull
    @Override
    public TenantViewAdapter onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        LayoutInflater layoutInflater=LayoutInflater.from(mCtx);
        View view=layoutInflater.inflate(R.layout.tenant_view,null);
        return new TenantViewAdapter(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TenantViewAdapter tenantViewAdapter, int i) {

        final Tenant tenant=tenantList.get(i);
        tenantViewAdapter.tvName.setText(tenant.getTenantName());
        tenantViewAdapter.tvPhone.setText(tenant.getPhone());
//        tenantViewAdapter.tvRoom.setText(tenant.getRoom());
        tenantViewAdapter.tvPayment.setText(String.format("%s",tenant.getRent()));
        tenantViewAdapter.tvBalance.setText(String.format("%s",tenant.getBalance()));

        Glide.with(mCtx)
                .load(tenant.getProfile())
                .into(tenantViewAdapter.imageTenant);

    }

    @Override
    public int getItemCount() {
        return tenantList.size();
    }

    class TenantViewAdapter extends RecyclerView.ViewHolder{

        ImageView imageTenant;
        TextView tvName,tvRoom,tvPhone,tvPayment,tvBalance;
        Button btnPay,btnRemove;
        public TenantViewAdapter(@NonNull View itemView) {
            super(itemView);

            imageTenant=(ImageView)itemView.findViewById(R.id.imageViewTenant);
            tvName=(TextView)itemView.findViewById(R.id.tenantName);
            tvRoom=(TextView)itemView.findViewById(R.id.tenantRoom);
            tvPhone=(TextView)itemView.findViewById(R.id.tenantPhone);
            tvPayment=(TextView)itemView.findViewById(R.id.tenantRent);
            tvBalance=(TextView)itemView.findViewById(R.id.tenantBalance);

        }
    }

}


