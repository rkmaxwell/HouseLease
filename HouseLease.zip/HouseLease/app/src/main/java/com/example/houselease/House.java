
package com.example.houselease;
public class House {

    private int id;
    private String tittle,category;
    private String description;
    private String location;
    private double Rating,Price;
    private String image;
    private String landlord;


    public House(int id, String tittle,String category,String description, String location, double rating, double price, String image,String landlord) {
        this.id = id;
        this.tittle = tittle;
        this.category=category;
        this.description = description;
        this.location = location;
        Rating = rating;
        Price = price;
        this.image = image;
        this.landlord=landlord;
    }

    public String getLandlord() {
        return landlord;
    }

    public void setLandlord(String landlord) {
        this.landlord = landlord;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTittle() {
        return tittle;
    }

    public void setTittle(String tittle) {
        this.tittle = tittle;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public double getRating() {
        return Rating;
    }

    public void setRating(double rating) {
        Rating = rating;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double price) {
        Price = price;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
