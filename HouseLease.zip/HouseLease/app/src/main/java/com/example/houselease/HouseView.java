package com.example.houselease;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HouseView extends AppCompatActivity implements HouseAdapter.onItemClickListener {

    RecyclerView recyclerView;
    HouseAdapter houseAdapter,adapter;
    List<House> houseList,houses;

    EditText searchBox;
    ImageView imageViewSearch;
    ProgressBar progressBar;
    final private String URLload="http:/192.168.43.182/rentals/houses.php";

    SwipeRefreshLayout swipeRefreshLayout;

    public static final String EXTRA_ID="id";
    public static final String EXTRA_NAME="name";
    public static final String EXTRA_LOCALE="location";
    public static final String EXTRA_URL="photo";
    public static final String EXTRA_PRICE="price";
    public static final String EXTRA_LOCATION="description";
    public static final String EXTRA_RATING="rate";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_house_view);

        findViewById(R.id.houseViewLayout).requestFocus();

        houseList = new ArrayList<>();
        houses = new ArrayList<>();
        recyclerView = (RecyclerView) findViewById(R.id.recyclerViewHouse);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        imageViewSearch = (ImageView) findViewById(R.id.imageSearch);
        searchBox = (EditText) findViewById(R.id.etSearchHouse);
        progressBar = (ProgressBar) findViewById(R.id.progressHouse);

        imageViewSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSearchedGas();
            }
        });

        loadProducts();


        Bundle bundle = getIntent().getExtras();

//        if (bundle != null) {
//
//            searchBox.setText(bundle.getString("apartment"));
//            getSearchedGas();
//
//        }else{
//            Toast.makeText(HouseView.this, "No info", Toast.LENGTH_SHORT).show();
//        }
         }

    private void loadProducts(){

        progressBar.setVisibility(View.VISIBLE);
        StringRequest stringRequest=new StringRequest(Request.Method.GET, URLload, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                progressBar.setVisibility(View.GONE);

                try {

                    JSONArray houses = new JSONArray(response);

                        for (int i = 0; i < houses.length(); i++) {
                            JSONObject houseObject = houses.getJSONObject(i);

                            int id = houseObject.getInt("id");
                            String name = houseObject.getString("name");
                            String category = houseObject.getString("category");
                            String description = houseObject.getString("description");
                            double price = houseObject.getDouble("price");
                            String image = houseObject.getString("photo");
                            String location = houseObject.getString("location");
                            String landlord = houseObject.getString("landlord");
                            double rate = houseObject.getDouble("rate");


                            //String place=houseObject.getString("location");

                            String imagePath = "http:/192.168.43.182/rentals/uploads/" + image;
                            String path = "http://leaseholder.mabnets.com/android/uploads/" + image;

                            //Toast.makeText(HouseView.this, imagePath, Toast.LENGTH_SHORT).show();

                            House house = new House(id, name,category, description, location, rate, price, imagePath,landlord);
                            houseList.add(house);
                            houseAdapter = new HouseAdapter(HouseView.this, houseList);
                            recyclerView.setAdapter(houseAdapter);

                            houseAdapter.setOnItemClickListener(HouseView.this);


                        }

                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressBar.setVisibility(View.GONE);
                AlertDialog.Builder alertDialog=new AlertDialog.Builder(HouseView.this);
                alertDialog.setMessage("Error, Please check your internet connection");
                alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {


                    }
                });
                alertDialog.create();
                alertDialog.show();

            }
        });
        Volley.newRequestQueue(this).add(stringRequest);
    }

    @Override
    public void onItemClick(int position) {
        Intent intent=new Intent(HouseView.this,DetailedActivity.class);
        House clickedHouse=houseList.get(position);
        intent.putExtra(EXTRA_ID,clickedHouse.getId());
        intent.putExtra(EXTRA_NAME,clickedHouse.getTittle());
        intent.putExtra(EXTRA_LOCALE,clickedHouse.getLocation());
        intent.putExtra(EXTRA_URL,clickedHouse.getImage());
        intent.putExtra(EXTRA_PRICE,clickedHouse.getPrice());
        intent.putExtra(EXTRA_LOCATION,clickedHouse.getDescription());
        intent.putExtra(EXTRA_RATING,clickedHouse.getRating());

        startActivity(intent);
    }

    private void getSearchedGas(){

        String URLSearch="http://192.168.43.182/rentals/search.php";
        final String search=searchBox.getText().toString().trim();
        if(TextUtils.isEmpty(search)){
            searchBox.requestFocus();
        }else{
            progressBar.setVisibility(View.VISIBLE);

            StringRequest stringRequest=new StringRequest(Request.Method.POST, URLSearch, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                  progressBar.setVisibility(View.GONE);
                    try{
                        JSONArray houseArray=new JSONArray(response);
                        if (houseArray.length() < 1) {
                            AlertDialog.Builder alertDialog=new AlertDialog.Builder(HouseView.this);
                            alertDialog.setMessage("Sorry, results for your search '"+search +"' were not found");
                            alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {


                                }
                            });
                            alertDialog.create();
                            alertDialog.show();

                        } else {
                            for (int i = 0; i < houseArray.length(); i++) {

                                JSONObject houseObject = houseArray.getJSONObject(i);
                                int id = houseObject.getInt("id");
                                String name = houseObject.getString("name");
                                String category = houseObject.getString("category");
                                String description = houseObject.getString("description");
                                double price = houseObject.getDouble("price");
                                String image = houseObject.getString("photo");
                                String location = houseObject.getString("location");
                                String landlord = houseObject.getString("landlord");
                                double rate = houseObject.getDouble("rate");


                                //String place=houseObject.getString("location");

                                String imagePath = "http:/192.168.43.182/rentals/uploads/" + image;
                                String path = "http://leaseholder.mabnets.com/android/uploads/" + image;

                                //Toast.makeText(HouseView.this, imagePath, Toast.LENGTH_SHORT).show();

                                House house = new House(id, name,category, description, location, rate, price, imagePath,landlord);
                                houses.add(house);
                                adapter = new HouseAdapter(HouseView.this, houses);
                                recyclerView.setAdapter(adapter);

                                adapter.setOnItemClickListener(HouseView.this);

                            }

                        }
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    progressBar.setVisibility(View.GONE);
                    AlertDialog.Builder alertDialog=new AlertDialog.Builder(HouseView.this);
                    alertDialog.setMessage("Error: Please check your internet connection");
                    alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    alertDialog.create();
                    alertDialog.show();
                }
            }){

                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String,String> params=new HashMap<>();
                    params.put("q",search);
                    return  params;
                }
            };

            Volley.newRequestQueue(HouseView.this).add(stringRequest);

        }
    }
}
