package com.example.houselease;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.HashMap;

public class Login extends AppCompatActivity {

    private EditText name,pass;
    private Button buttonLogin;
    private ProgressBar progressBar;
    private TextView textViewForgot,textViewRegister;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        name=(EditText)findViewById(R.id.usernames);
        pass=(EditText)findViewById(R.id.password);
        buttonLogin=(Button)findViewById(R.id.btnLogin);
        textViewForgot=(TextView)findViewById(R.id.tvForgot);
        textViewRegister=(TextView)findViewById(R.id.tvRegister);
        textViewForgot=(TextView)findViewById(R.id.tvForgot);

        progressBar=(ProgressBar)findViewById(R.id.LoginProgressBar);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });
        textViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this,Registration.class));
            }
        });

        textViewForgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this,forgot_password.class));
            }
        });


    }
    public void loginUser(){

        final String username=name.getText().toString().trim();
        final String password=pass.getText().toString().trim();

        if(TextUtils.isEmpty(username)){
            name.setError("Email is required");
            name.requestFocus();
        }else if(TextUtils.isEmpty(password)){
            pass.setError("Enter your password");
            pass.requestFocus();
        }else {


            class UserLogin extends AsyncTask<Void,Void,String> {


                @Override
                protected void onPreExecute() {
                    super.onPreExecute();

                    progressBar.setVisibility(View.VISIBLE);
                }

                @Override
                protected void onPostExecute(String s) {
                    super.onPostExecute(s);
                    progressBar.setVisibility(View.GONE);

                    try{

                        JSONObject jsonObject=new JSONObject(s);

                        if(!jsonObject.getBoolean("error")){
                            Toast.makeText(getApplicationContext(), jsonObject.getString("message"), Toast.LENGTH_SHORT).show();

                            JSONObject  userJson=jsonObject.getJSONObject("user");

                            User user=new User(
                                    userJson.getInt("id"),
                                    userJson.getString("email")
                            );

                            SharedPrefManager.getInstance(getApplicationContext()).userLogin(user);

                            finish();
                            startActivity(new Intent(Login.this,RentHome.class));
                            Toast.makeText(Login.this, user.getEmail(), Toast.LENGTH_SHORT).show();
                        }else{

                            Toast.makeText(Login.this, "Incorrect username or password", Toast.LENGTH_SHORT).show();
                            Toast.makeText(Login.this, jsonObject.getString("error"), Toast.LENGTH_SHORT).show();

                        }

                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }

                @Override
                protected String doInBackground(Void... voids) {
                    String urlLogin="http://192.168.43.182/rentals/Api.php?apicall=login";

                    RequestHandler requestHandler=new RequestHandler();
                    HashMap<String,String> params=new HashMap<>();
                    params.put("email",username);
                    params.put("pass",password);

                    return requestHandler.sendPostRequest(urlLogin,params);
                }
            }
            UserLogin userLogin=new UserLogin();
            userLogin.execute();
        }
    }

}
