package com.example.houselease;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class forgot_password extends AppCompatActivity {

    private EditText etEmail,etCode;
    private Button btnSend,btnCheck;
    TextView textViewResend;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        etEmail=(EditText)findViewById(R.id.forgotMail);
        etCode=(EditText)findViewById(R.id.forgotCode);

        btnSend=(Button)findViewById(R.id.btnSendCode);
        btnCheck=(Button)findViewById(R.id.btnVerifyCode);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCode();
            }
        });
    }

    private void sendCode(){

        final String email=etEmail.getText().toString().trim();

        if(TextUtils.isEmpty(email)){
            etEmail.setError("Enter email used in registration");
            etEmail.requestFocus();
        }else{

            String URLcode="http://192.168.43.182/rentals/resetpassword.php";

            StringRequest stringRequest=new StringRequest(Request.Method.POST, URLcode, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    Toast.makeText(forgot_password.this, response, Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    Toast.makeText(forgot_password.this, error.toString(), Toast.LENGTH_SHORT).show();
                }
            }){

                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    final String email=etEmail.getText().toString().trim();

                    Map<String,String> params=new HashMap<>();
                    params.put("email",email);

                    return  params;
                }
            };
            Volley.newRequestQueue(forgot_password.this).add(stringRequest);


        }
    }
}
