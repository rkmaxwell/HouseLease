package com.example.houselease;

public class Tenant {
    int tenant_id,room;
    String tenantName,phone,profile;
    double rent,balance;

    public Tenant(int tenant_id, int room, String tenantName, String phone, String profile, double rent, double balance) {
        this.tenant_id = tenant_id;
        this.room = room;
        this.tenantName = tenantName;
        this.phone = phone;
        this.profile = profile;
        this.rent = rent;
        this.balance = balance;
    }

    public int getTenant_id() {
        return tenant_id;
    }

    public void setTenant_id(int tenant_id) {
        this.tenant_id = tenant_id;
    }

    public int getRoom() {
        return room;
    }

    public void setRoom(int room) {
        this.room = room;
    }

    public String getTenantName() {
        return tenantName;
    }

    public void setTenantName(String tenantName) {
        this.tenantName = tenantName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }

    public double getRent() {
        return rent;
    }

    public void setRent(double rent) {
        this.rent = rent;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
