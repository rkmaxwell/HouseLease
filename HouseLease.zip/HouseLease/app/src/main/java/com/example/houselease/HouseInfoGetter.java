package com.example.houselease;

public class HouseInfoGetter {
    int id;
    String name,tenant;

    public HouseInfoGetter(int id, String name, String tenant) {
        this.id = id;
        this.name = name;
        this.tenant = tenant;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTenant() {
        return tenant;
    }

    public void setTenant(String tenant) {
        this.tenant = tenant;
    }
}
