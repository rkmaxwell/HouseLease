package com.example.houselease;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.smarteist.autoimageslider.DefaultSliderView;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderLayout;
import com.smarteist.autoimageslider.SliderView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RentHome extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {



    RecyclerView recyclerView,recyclerViewMultiple;
    LandlordAdapter landlordAdapter;
    List<RegisteredLandlord> landlordList;

    SwitcherAdapter switcherAdapter;
    List<House> houseList;

    TextView textViewName,textViewEmail;
    private Button aButton,bButton,cButton,dButton,eButton;
    private TextView houseName,houseLocation,housePrice,houseBeds;
    private ImageView imageHouse;
    String email;
    String image;
    private int loggedID;
    private final String URLHouse="http:/192.168.43.182/rentals/onehouse.php";

    SliderLayout sliderLayout;

    static final String APARTMENT="apartment";
    static final String SINGLE="single";
    static final String FAMILY="family";
    static final String BEDSITTER="bedsitter";
    static final String HIGH_RATE="high";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rent_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        aButton=(Button)findViewById(R.id.button1);
        bButton=(Button)findViewById(R.id.button2);
        cButton=(Button)findViewById(R.id.button3);
        dButton=(Button)findViewById(R.id.button4);
        eButton=(Button)findViewById(R.id.button5);

      aButton.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Intent intent=new Intent(RentHome.this,HouseView.class);
              intent.putExtra(APARTMENT,"apartment");
              startActivity(intent);
          }
      });
        bButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(RentHome.this,HouseView.class);
                intent.putExtra(BEDSITTER,"apartment");
                startActivity(intent);
            }
        });
        cButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(RentHome.this,HouseView.class);
                intent.putExtra(FAMILY,"apartment");
                startActivity(intent);
            }
        });
        dButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(RentHome.this,HouseView.class);
                intent.putExtra(SINGLE,"apartment");
                startActivity(intent);
            }
        });
        eButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(RentHome.this,HouseView.class);
                intent.putExtra(HIGH_RATE,"apartment");
                startActivity(intent);
            }
        });

        sliderLayout=(SliderLayout)findViewById(R.id.imageSliderHome);
        sliderLayout.setIndicatorAnimation(IndicatorAnimations.FILL);
        sliderLayout.setScrollTimeInSec(1);

        setSliderViews();

//        houseList=new ArrayList<>();
//        recyclerViewMultiple=(RecyclerView)findViewById(R.id.recyclerViewSwitcher);
//        recyclerViewMultiple.setHasFixedSize(true);
//        recyclerViewMultiple.setLayoutManager(new LinearLayoutManager(this));

        //home

        houseName=(TextView)findViewById(R.id.tvHouseName);
        houseLocation=(TextView)findViewById(R.id.tvHouseLocation);
        imageHouse=(ImageView)findViewById(R.id.imageViewHome);
        housePrice=(TextView)findViewById(R.id.tvHousePrice);
        houseBeds=(TextView)findViewById(R.id.tvHouseBeds);


        loadLatestHouse();

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        View navHeader=navigationView.getHeaderView(0);
        TextView textView=(TextView)navHeader.findViewById(R.id.tvCompanyName);
        TextView textViews=(TextView)navHeader.findViewById(R.id.tvCompanyText);
        textView.setText(R.string.app_name);
        textViews.setText("Home away from home");


    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.rent_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

            startActivity(new Intent(RentHome.this,HouseView.class));
        } else if (id == R.id.nav_slideshow) {

            startActivity(new Intent(RentHome.this,LandlordLogin.class));

        } else if (id == R.id.nav_manage) {

            startActivity(new Intent(RentHome.this,HouseScroll.class));

        } else if (id == R.id.nav_share) {

            Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
            sharingIntent.setType("text/plain");
            String shareBodyText = "Check it out. Your message goes here";
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,"Subject here");
            sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBodyText);
            startActivity(Intent.createChooser(sharingIntent, "Shearing Option"));
            return true;
        } else if (id == R.id.nav_send) {

        }else if(id == R.id.nav_profile){
            startActivity(new Intent(RentHome.this,Profile.class));
        }else if(id== R.id.nav_developer){
            startActivity(new Intent(RentHome.this,Developer.class));
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void loadLatestHouse(){

        final StringRequest stringRequest=new StringRequest(Request.Method.POST, URLHouse, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                //Toast.makeText(RentHome.this, response, Toast.LENGTH_SHORT).show();

                try {

                    JSONArray houses = new JSONArray(response);
                    for (int i = 0; i < houses.length(); i++) {
                        JSONObject houseObject = houses.getJSONObject(i);

                        image=houseObject.getString("photo");
                        String name=houseObject.getString("name");
                        String location=houseObject.getString("location");
                        String price=houseObject.getString("price");
                        String describe=houseObject.getString("description");
                        String imagePath="http:/192.168.43.182/rentals/uploads/"+image;

                        Glide.with(RentHome.this)
                                .load(imagePath)
                                .into(imageHouse);

                        houseName.setText(name);
                        houseLocation.setText(location);
                        houseBeds.setText(describe);
                        housePrice.setText("KES "+price +" PM");
                        //Toast.makeText(MainActivity.this, image, Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


                AlertDialog.Builder alertDialog=new AlertDialog.Builder(RentHome.this);
                alertDialog.setMessage("Error, Please check your internet connection");
                alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alertDialog.setPositiveButton("RETRY", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        loadLatestHouse();
                    }
                });
                alertDialog.create();
                alertDialog.show();
            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params=new HashMap<>();
                params.put("latest","1");

                return  params;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue(RentHome.this);
        requestQueue.add(stringRequest);


    }

    private void loadMultiImage(){

        final  String URLload="http:/192.168.43.182/rentals/houses.php";

        StringRequest stringRequest=new StringRequest(Request.Method.GET, URLload, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Toast.makeText(RentHome.this, response, Toast.LENGTH_SHORT).show();

                try{

                    JSONArray houses=new JSONArray(response);

                    for(int i=0;i<houses.length();i++){
                        JSONObject houseObject=houses.getJSONObject(i);

                        int id=houseObject.getInt("id");
                        String name=houseObject.getString("name");
                        String category = houseObject.getString("category");
                        String description=houseObject.getString("description");
                        double price=houseObject.getDouble("price");
                        String image=houseObject.getString("photo");
                        String location=houseObject.getString("location");
                        String landlord = houseObject.getString("landlord");
                        double rate=houseObject.getDouble("rate");


                        //String place=houseObject.getString("location");

                        String imagePath="http:/192.168.43.182/rentals/uploads/"+image;
                        String path="http://leaseholder.mabnets.com/android/uploads/"+image;

                        Toast.makeText(RentHome.this, imagePath, Toast.LENGTH_SHORT).show();

                        House house=new House(id,name,category,description,location,rate,price,imagePath,landlord);
//                        houseList.add(house);
//                        switcherAdapter=new SwitcherAdapter(RentHome.this,houseList);
//                        recyclerViewMultiple.setAdapter(switcherAdapter);


                    }
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        Volley.newRequestQueue(RentHome.this).add(stringRequest);
    }

    private void setSliderViews() {

        for (int i = 0; i <= 3; i++) {

            DefaultSliderView sliderView = new DefaultSliderView(this);

            switch (i) {
                case 0:
                    sliderView.setImageUrl("http://192.168.43.182/rentals/uploads/PROD-20190411-154011.jpg");
                    sliderView.setDescription("Amani Rentals, Nakuru");
                    break;
                case 1:
                    sliderView.setImageUrl("http://192.168.43.182/rentals/uploads/PROD-20190416-064207.jpg");
                    break;
                case 2:
                    sliderView.setImageUrl("http://192.168.43.182/rentals/uploads/PROD-20190416-063723.jpg");
                    break;
                case 3:
                    sliderView.setImageUrl("http://192.168.43.182/rentals/uploads/PROD-20190414-130852.jpg");
                    break;
            }

            sliderView.setImageScaleType(ImageView.ScaleType.CENTER_CROP);
            sliderView.setDescription("Take a tour at some our apartment rentals");
            final int finalI = i;
            sliderView.setOnSliderClickListener(new SliderView.OnSliderClickListener() {
                @Override
                public void onSliderClick(SliderView sliderView) {
                    Toast.makeText(RentHome.this, "This is slider " + (finalI + 1), Toast.LENGTH_SHORT).show();
                }
            });

            //at last add this view in your layout :
            sliderLayout.addSliderView(sliderView);
        }
    }

    public void shareText(View view){

        Intent intent = new Intent(android.content.Intent.ACTION_SEND);
        intent.setType("text/plain");
        String shareBodyText = "Your shearing message goes here";
        intent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject/Title");
        intent.putExtra(android.content.Intent.EXTRA_TEXT, shareBodyText);
        startActivity(Intent.createChooser(intent, "Choose sharing method"));
    }
}
