package com.example.houselease;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class DetailedActivity extends AppCompatActivity {

    int sid, hid;
    String email, name, description, image, location;
    double price, rate;

    ImageView imageViewHouse;
    TextView textViewName, textViewPrice, textViewLocation, textViewRate;
    Button buttonBook;
    private EditText cost, owner, code, tillNumber, houseDates, dateLeave;
    String landlord;

    private ProgressBar progressBar;
    final String URLGetLandlord = "http://192.168.43.182/rentals/landlord.php";

    private DatePicker datePicker;
    private Calendar calendar;
    private TextView datePicked, leaveDate;
    private int year, month, date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed);

        datePicked = (TextView) findViewById(R.id.dateView);
        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        date = calendar.get(Calendar.DAY_OF_MONTH);
        showDate(year, month + 1, date);


        textViewName = (TextView) findViewById(R.id.houseBookName);
        textViewPrice = (TextView) findViewById(R.id.houseBookPrice);
        textViewLocation = (TextView) findViewById(R.id.houseBookLocation);
        leaveDate = (TextView) findViewById(R.id.dateViewLeave);
        progressBar = (ProgressBar) findViewById(R.id.progressBook);


        imageViewHouse = (ImageView) findViewById(R.id.imageViewBook);
        buttonBook = (Button) findViewById(R.id.bookButton);

        cost = (EditText) findViewById(R.id.houseFee);
        owner = (EditText) findViewById(R.id.houseOwner);
        code = (EditText) findViewById(R.id.houseMessage);
        tillNumber = (EditText) findViewById(R.id.TillNumber);
        houseDates = (EditText) findViewById(R.id.houseDate);
        dateLeave = (EditText) findViewById(R.id.houseLeaveDate);

        cost.setFocusable(false);
        owner.setFocusable(false);
        leaveDate.setText("");

        findViewById(R.id.mainLayout).requestFocus();
        if (!SharedPrefManager.getInstance(DetailedActivity.this).isLoggedIn()) {

            Intent intent = new Intent(DetailedActivity.this, Login.class);
            startActivity(intent);

        } else {
            User user = SharedPrefManager.getInstance(DetailedActivity.this).getUser();
            sid = user.getId();
            email = user.getEmail();
        }
        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {

            name = bundle.getString("name");
            price = bundle.getDouble("price");
            description = bundle.getString("description");
            image = bundle.getString("photo");
            hid = bundle.getInt("id");
            rate = bundle.getDouble("rate");
            location = bundle.getString("location");

            Glide.with(DetailedActivity.this)
                    .load(image)
                    .into(imageViewHouse);

            textViewName.setText(name);
            textViewPrice.setText(String.format("%s", price));
            textViewLocation.setText(description);

            cost.setText(String.format("KSH.\t%s ", price));
            tillNumber.setText("102400");
            tillNumber.setFocusable(false);


            getLandlord();

        }
        buttonBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bookHouse();
            }
        });

        houseDates.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setDate(v);
            }
        });
        dateLeave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setEndDate(v);

            }
        });


    }

    @SuppressWarnings("deprecation")
    public void setDate(View view) {
        showDialog(999);
        Toast.makeText(getApplicationContext(), "Pick date", Toast.LENGTH_SHORT)
                .show();
    }
    public void setEndDate(View view) {
        showDialog(111);
        Toast.makeText(getApplicationContext(), "Pick date", Toast.LENGTH_SHORT)
                .show();
    }


    @Override
    protected Dialog onCreateDialog(int id) {

        if(id==999){
            return new DatePickerDialog(this,myDateListener,year,month,date);
        }else if(id==111){
            return new DatePickerDialog(this,myListener,year,month,date);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener =new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            showDate(year,month+1,dayOfMonth);
        }
    };

    private DatePickerDialog.OnDateSetListener myListener=new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            showEndDate(year,month+1,dayOfMonth);
        }
    };


    private void showDate(int year, int month, int day) {
        datePicked.setText(new StringBuilder().append(day).append("/")
                .append(month).append("/").append(year));
    }
    private void showEndDate(int year, int month, int day) {
        leaveDate.setText(new StringBuilder().append(day).append("/")
                .append(month).append("/").append(year));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    private void getLandlord(){
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URLGetLandlord, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Toast.makeText(DetailedActivity.this, "Landlord: "+response, Toast.LENGTH_LONG).show();
                landlord=response;
                owner.setText(landlord);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(DetailedActivity.this, "An error occurred, try again", Toast.LENGTH_LONG).show();
            }
        }){


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params=new HashMap<>();

                params.put("house",String.format("%s",hid));

                return  params;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue(DetailedActivity.this);
        requestQueue.add(stringRequest);
    }

    private void bookHouse(){

        String URLBook="http:/192.168.43.182/rentals/booking.php";

        final String admission= (String) datePicked.getText();
        final String dismission=(String) leaveDate.getText();

        Toast.makeText(DetailedActivity.this, dismission, Toast.LENGTH_SHORT).show();
        if(TextUtils.isEmpty(admission)){
            houseDates.setError("Pick your arrival date");
            houseDates.requestFocus();
        }else if(leaveDate.getText()==""){
            dateLeave.setError("When are you leaving");
            dateLeave.requestFocus();
        }else{

            dateLeave.setText(dismission);
            progressBar.setVisibility(View.VISIBLE);
            StringRequest stringRequest=new StringRequest(Request.Method.POST, URLBook, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(DetailedActivity.this, response, Toast.LENGTH_LONG).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    progressBar.setVisibility(View.GONE);
                    //Toast.makeText(DetailedActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    Toast.makeText(DetailedActivity.this, "An error occurred, please try again", Toast.LENGTH_LONG).show();
                }
            }){

                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    String houseID=String.format("%s",hid);
                    String tenantID=String.format("%s",sid);
                    String payment= (String) textViewPrice.getText();

                    final String admission= (String) datePicked.getText();
                    final String dismission=(String) leaveDate.getText();


                    Toast.makeText(DetailedActivity.this, admission, Toast.LENGTH_SHORT).show();
                    Toast.makeText(DetailedActivity.this, dismission, Toast.LENGTH_SHORT).show();
                    Map<String,String> params=new HashMap<>();
                    params.put("tenant",tenantID);
                    params.put("house",houseID);
                    params.put("payment",payment);
                    params.put("admission",admission);
                    params.put("dismission",dismission);


                    return  params;
                }
            };
            RequestQueue requestQueue=Volley.newRequestQueue(DetailedActivity.this);
            requestQueue.add(stringRequest);
        }



    }
}
