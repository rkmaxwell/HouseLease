package com.example.houselease;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class LandlordController extends AppCompatActivity {

    ImageView imageViewAdd,imageViewDelete,imageViewTenants,imageViewChat,imageViewRentals;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landlord_controller);

        imageViewAdd=(ImageView)findViewById(R.id.imgAddItem);
        imageViewDelete=(ImageView)findViewById(R.id.imgDeleteItem);
        imageViewTenants=(ImageView)findViewById(R.id.imgTenants);
        imageViewChat=(ImageView)findViewById(R.id.imgChat);
        imageViewRentals=(ImageView)findViewById(R.id.imgRentals);

        imageViewAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(LandlordController.this,UploadHouse.class);
                startActivity(intent);
            }
        });

        imageViewTenants.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LandlordController.this,TenantView.class));
            }
        });

        imageViewDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LandlordController.this,ManageHouses.class));
            }
        });

    }
}
