package com.example.houselease;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class SharePrefLandlordManager {

  private static final String SHARED_PREF_NAME="com.maxwell.app";
  private static final String KEY_USERNAME="keyusername";
  private static final String KEY_EMAIL="keyemail";
  private static final String KEY_ID="keyid";
  private static final String KEY_ACCOUNT="keyaccount";

  private static SharePrefLandlordManager mInstance;
  private static Context mCtx;

  private SharePrefLandlordManager(Context context){
    mCtx=context;
  }

  public static synchronized SharePrefLandlordManager getInstance(Context context){
    if(mInstance==null){
      mInstance=new SharePrefLandlordManager(context);
    }
    return mInstance;
  }

  public void userLogin(Landlord landlord){
    SharedPreferences sharedPreferences=mCtx.getSharedPreferences(SHARED_PREF_NAME,Context.MODE_PRIVATE);
    SharedPreferences.Editor editor=sharedPreferences.edit();
    editor.putInt(KEY_ID, landlord.getId());
    editor.putString(KEY_EMAIL, landlord.getEmail());
    editor.apply();
  }
  public boolean isLoggedIn(){
    SharedPreferences sharedPreferences=mCtx.getSharedPreferences(SHARED_PREF_NAME,Context.MODE_PRIVATE);
    return sharedPreferences.getString(KEY_EMAIL,null)!=null;

  }
  public Landlord getLandlord(){
    SharedPreferences sharedPreferences=mCtx.getSharedPreferences(SHARED_PREF_NAME,Context.MODE_PRIVATE);
    return new Landlord(
            sharedPreferences.getInt(KEY_ID,-1),
            sharedPreferences.getString(KEY_EMAIL,null));
  }
  public void logout(){
    SharedPreferences sharedPreferences=mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
    SharedPreferences.Editor editor=sharedPreferences.edit();
    editor.clear();
    editor.apply();
    mCtx.startActivity(new Intent(mCtx, Login.class));

  }
}
