package com.example.houselease;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONObject;

public class HouseDetail extends AppCompatActivity {
    String id;

    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_house_detail);

        Bundle bundle=getIntent().getExtras();

        imageView=(ImageView)findViewById(R.id.checkedHouse);

        if(bundle != null){

             id=bundle.getString("id");
           // Toast.makeText(HouseDetail.this, id, Toast.LENGTH_SHORT).show();


            getCheckedHouse();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.zoom_options,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case R.id.zoom_out:
                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.image_zoom);
                imageView.startAnimation(animation);
                return true;
        }
        return false;
    }

    private void getCheckedHouse(){

        int houseID=Integer.parseInt(id);

        String URLHouse="http://192.168.43.182/rentals/chouse.php?hid="+houseID;

        StringRequest stringRequest=new StringRequest(Request.Method.GET, URLHouse, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                //Toast.makeText(HouseDetail.this, response.trim(), Toast.LENGTH_SHORT).show();
                try {

                    JSONArray houses = new JSONArray(response);

                    for (int i = 0; i < houses.length(); i++) {
                        JSONObject houseObject = houses.getJSONObject(i);

                        int id = houseObject.getInt("id");
                        String name = houseObject.getString("name");
                        String description = houseObject.getString("description");
                        double price = houseObject.getDouble("price");
                        String image = houseObject.getString("photo");
                        String location = houseObject.getString("location");
                        double rate = houseObject.getDouble("rate");


                        //String place=houseObject.getString("location");

                        String imagePath = "http:/192.168.43.182/rentals/uploads/" + image;
                        String path = "http://leaseholder.mabnets.com/android/uploads/" + image;

                        Glide.with(HouseDetail.this)
                                .load(imagePath)
                                .into(imageView);

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


                AlertDialog.Builder alertDialog=new AlertDialog.Builder(HouseDetail.this);
                alertDialog.setMessage("Error, Please check your internet connection");
                alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alertDialog.setPositiveButton("RETRY", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        getCheckedHouse();
                    }
                });
                alertDialog.create();
                alertDialog.show();
            }
        });

        Volley.newRequestQueue(HouseDetail.this).add(stringRequest);
    }
}
