package com.example.houselease;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class ManageHouseAdapter extends RecyclerView.Adapter<ManageHouseAdapter.ManageHouseViewHolder> {

    private Context mCtx;
    private List<HouseInfoGetter> houses;

    public ManageHouseAdapter(Context mCtx, List<HouseInfoGetter> houses) {
        this.mCtx = mCtx;
        this.houses = houses;
    }

    @NonNull
    @Override
    public ManageHouseViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        LayoutInflater layoutInflater=LayoutInflater.from(mCtx);
        View view=layoutInflater.inflate(R.layout.house_manage_layout,null);
        return  new ManageHouseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ManageHouseViewHolder manageHouseViewHolder, int i) {

        final HouseInfoGetter house=houses.get(i);
        manageHouseViewHolder.houseName.setText(house.getName());
        manageHouseViewHolder.houseOccupant.setText(house.getTenant());
    }

    @Override
    public int getItemCount() {
        return houses.size();
    }

    class ManageHouseViewHolder extends RecyclerView.ViewHolder{

        TextView houseName,houseOccupant;
        public ManageHouseViewHolder(@NonNull View itemView) {
            super(itemView);

            houseName=(TextView)itemView.findViewById(R.id.houseMName);
            houseOccupant=(TextView)itemView.findViewById(R.id.mHouseOccupant);
        }
    }
}
