package com.example.houselease;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.toolbox.StringRequest;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;


import java.util.List;

public class HouseAdapter extends RecyclerView.Adapter<HouseAdapter.HouseViewHolder> {


    private Context mCtx;
    private List<House> houseList;


    private onItemClickListener mListener;


    public interface onItemClickListener{
        void onItemClick(int position);
    }

    public void setOnItemClickListener (onItemClickListener listener){
        mListener=listener;
    }

    public HouseAdapter(Context mCtx, List<House> houseList) {
        this.mCtx = mCtx;
        this.houseList = houseList;
    }


    @NonNull
    @Override
    public HouseViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

     LayoutInflater layoutInflater=LayoutInflater.from(mCtx);
     View view=layoutInflater.inflate(R.layout.list_layout,null);
     HouseViewHolder holder=new HouseViewHolder(view);
     return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final HouseViewHolder houseViewHolder, int i) {

        final House house=houseList.get(i);
        houseViewHolder.textViewName.setText(house.getTittle());
        houseViewHolder.textViewLocation.setText(house.getLocation());
        houseViewHolder.textViewDesc.setText(house.getDescription());
        houseViewHolder.textViewPrice.setText("KES "+String.valueOf(house.getPrice())+" PM");
        houseViewHolder.textViewRater.setText(String.valueOf(house.getRating()));


        Glide.with(mCtx)
                .load(house.getImage())
                .transition(DrawableTransitionOptions.withCrossFade())
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(houseViewHolder.imageView);


        houseViewHolder.imageViewMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

              Intent intent=new Intent(mCtx,HouseDetail.class);
              intent.putExtra("id",String.format("%s",house.getId()));
              mCtx.startActivity(intent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return houseList.size();
    }

    class HouseViewHolder extends RecyclerView.ViewHolder{

        TextView textViewName,textViewPrice,textViewLocation,textViewDesc,textViewRater;
        ImageView imageView,imageViewMore;
        Button rateButton;
        public HouseViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView=(ImageView)itemView.findViewById(R.id.imageViewHouse);
            textViewName=(TextView)itemView.findViewById(R.id.tvName);
            textViewPrice=(TextView)itemView.findViewById(R.id.tvPrice);
            textViewLocation=(TextView)itemView.findViewById(R.id.tvLocation);
            textViewDesc=(TextView)itemView.findViewById(R.id.tvDescription);
            textViewRater=(TextView)itemView.findViewById(R.id.tvRating);
            rateButton=(Button)itemView.findViewById(R.id.buttonBook);

            imageViewMore=(ImageView)itemView.findViewById(R.id.imgHouseMore);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mListener!=null){
                        int position=getAdapterPosition();
                        if(position!=RecyclerView.NO_POSITION){
                            mListener.onItemClick(position);
                        }
                    }
                }
            });

            rateButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mListener != null){
                        int position=getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION){
                            mListener.onItemClick(position);
                        }
                    }
                }
            });


        }
    }
}
