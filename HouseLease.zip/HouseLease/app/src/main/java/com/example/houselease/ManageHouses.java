package com.example.houselease;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ManageHouses extends AppCompatActivity {

     RecyclerView recyclerView;
     List<HouseInfoGetter> houseInfoGetters;
     ManageHouseAdapter manageHouseAdapter;

     String email;int sid;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_houses);

        if(!SharePrefLandlordManager.getInstance(ManageHouses.this).isLoggedIn()){

            startActivity(new Intent(ManageHouses.this,LandlordLogin.class));

        }else{

            Landlord landlord=SharePrefLandlordManager.getInstance(ManageHouses.this).getLandlord();
            email=landlord.getEmail();
            sid=landlord.getId();

        }

        houseInfoGetters=new ArrayList<>();
        recyclerView=(RecyclerView)findViewById(R.id.recyclerViewManageHouse);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadMyHouses();

    }


    private void loadMyHouses(){

        final String URLHouses="http://192.168.43.182/rentals/getMyHouses.php?sid="+sid;

        StringRequest stringRequest=new StringRequest(Request.Method.GET, URLHouses, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Toast.makeText(ManageHouses.this, response, Toast.LENGTH_SHORT).show();

                try {

                    JSONArray houses = new JSONArray(response);

                    for (int i = 0; i < houses.length(); i++) {
                        JSONObject houseObject = houses.getJSONObject(i);


                        int houseid=houseObject.getInt("id");
                        String housename=houseObject.getString("house");
                        String tenant=houseObject.getString("tenant");

                        HouseInfoGetter getter=new HouseInfoGetter(houseid,housename,tenant);
                        houseInfoGetters.add(getter);
                        manageHouseAdapter=new ManageHouseAdapter(ManageHouses.this,houseInfoGetters);
                        recyclerView.setAdapter(manageHouseAdapter);



                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


                Toast.makeText(ManageHouses.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        });

        Volley.newRequestQueue(ManageHouses.this).add(stringRequest);


    }

}
