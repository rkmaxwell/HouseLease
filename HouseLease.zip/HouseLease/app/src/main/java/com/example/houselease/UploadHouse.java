package com.example.houselease;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class UploadHouse extends AppCompatActivity {

    private EditText housename,houselocation,houseprice,housedescription;
    private Button buttonUpload;
    Spinner prodSpinner;
    ImageView imageView;
    ProgressBar progressBar;

    final String tag=this.getClass().getName();
    int sid;

    private static final int REQUEST_CODE_GALLERY=999;
    private static final int STORAGE_PERMISSION_CODE=123;
    Bitmap bitmap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_house);

        housename=(EditText)findViewById(R.id.prodName);
        houselocation=(EditText)findViewById(R.id.prodLocation);
        houseprice=(EditText)findViewById(R.id.prodPrice);
        housedescription=(EditText)findViewById(R.id.prodDescription);
        progressBar=(ProgressBar)findViewById(R.id.progressUpload);


        buttonUpload=(Button)findViewById(R.id.buttonUploadHouse);
        prodSpinner=(Spinner)findViewById(R.id.houseSpinner);
        imageView=(ImageView)findViewById(R.id.imgUploader);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityCompat.requestPermissions(UploadHouse.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},REQUEST_CODE_GALLERY);
            }
        });

        buttonUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendHouse();
            }
        });

        if(!SharePrefLandlordManager.getInstance(this).isLoggedIn()){
            startActivity(new Intent(UploadHouse.this,LandlordLogin.class));

        }else{
            Landlord landlord=SharePrefLandlordManager.getInstance(UploadHouse.this).getLandlord();
            String email=landlord.getEmail();

            sid=landlord.getId();
            Log.d(tag,String.format("%s",sid));
        }

        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,R.array.house_array,android.R.layout.simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        prodSpinner.setAdapter(adapter);
    }

    public void sendHouse(){
        String urlUpload="http://192.168.43.182/rentals/houseuploader.php?sid="+sid;

        final String name=housename.getText().toString().trim();
        final String locale=houselocation.getText().toString().trim();
        final String cost=houseprice.getText().toString().trim();
        final String description=housedescription.getText().toString().trim();
        final String categ=prodSpinner.getSelectedItem().toString().trim();


        if(TextUtils.isEmpty(name)){
            housename.setError("House name required");
            housename.requestFocus();
        }else if(TextUtils.isEmpty(locale)){
            houselocation.setError("Enter location of the rentals");
            houselocation.requestFocus();
        }else if(TextUtils.isEmpty(cost)){
            houseprice.setError("Enter cost per night");
            houseprice.requestFocus();
        }else if(TextUtils.isEmpty(description)){
            housedescription.setError("Description e.g perimeter fence");
            housedescription.requestFocus();
        }else {

            progressBar.setVisibility(View.VISIBLE);
            StringRequest stringRequest=new StringRequest(Request.Method.POST, urlUpload, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(UploadHouse.this, response, Toast.LENGTH_SHORT).show();

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(UploadHouse.this, error.toString(), Toast.LENGTH_SHORT).show();

                }
            }){

                @Override
                protected Map <String, String> getParams() throws AuthFailureError {
                    final String name=housename.getText().toString().trim();
                    final String locale=houselocation.getText().toString().trim();
                    final String cost=houseprice.getText().toString().trim();
                    final String description=housedescription.getText().toString().trim();
                    final String categ=prodSpinner.getSelectedItem().toString().trim();
                    Map<String,String> params=new HashMap<>();
                    String imageData=imageToString(bitmap);
                    params.put("housename",name);
                    params.put("location",locale);
                    params.put("cost",cost);
                    params.put("description",description);
                    params.put("house",categ);
                    params.put("photo",imageData);

                    return  params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(UploadHouse.this);
            requestQueue.add(stringRequest);
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(6000,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode== REQUEST_CODE_GALLERY){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Intent galleryIntent=new Intent(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent,REQUEST_CODE_GALLERY);
            }else{
                Toast.makeText(UploadHouse.this, "HouseLease doesn't have permission", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        try {

            if(data!=null) {
                Uri imageUri = data.getData();


                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                bitmap = BitmapFactory.decodeStream(inputStream);
                imageView.setImageBitmap(bitmap);
            }
            else{
                return;
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    private  String  imageToString(Bitmap bitmap){
        ByteArrayOutputStream outputStream=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,outputStream);
        byte[] imageBytes=outputStream.toByteArray();

        String encodedimage= Base64.encodeToString(imageBytes,Base64.DEFAULT);
        return  encodedimage;
    }
}
