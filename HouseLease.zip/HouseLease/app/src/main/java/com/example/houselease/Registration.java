package com.example.houselease;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class Registration extends AppCompatActivity {

    private EditText name,phone,email,password,cPassword;
    private Button registerButton;
    private ProgressBar progressBar;
    private TextView loginTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        name=(EditText)findViewById(R.id.regName);
        phone=(EditText)findViewById(R.id.regPhone);
        email=(EditText)findViewById(R.id.regEmail);
        password=(EditText)findViewById(R.id.regPassword);
        cPassword=(EditText)findViewById(R.id.regConfirmPassword);
        loginTextView=(TextView)findViewById(R.id.tvLogin);

        registerButton=(Button)findViewById(R.id.btnRegister);
        progressBar=(ProgressBar)findViewById(R.id.registerProgressBar);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

        loginTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Registration.this,Login.class));
            }
        });

        findViewById(R.id.regLayout).requestFocus();
    }

    private void registerUser(){

        final String URLRegister="http://192.168.43.182/rentals/register.php";
        final String username=name.getText().toString().trim();
        final String phoneNumber=phone.getText().toString().trim();
        final String mail=email.getText().toString().trim();
        final String pass=password.getText().toString().trim();
        String cPass=cPassword.getText().toString().trim();

        if(TextUtils.isEmpty(username)) {
            name.setError("Please enter your name");
            name.requestFocus();

        }
        else if(TextUtils.isEmpty(mail)){
            email.setError("Enter your email address");
            email.requestFocus();
        }else if(TextUtils.isEmpty(phoneNumber)){
            phone.setError("Phone number required");
            phone.requestFocus();
        }else if(phone.length()!=10){
            phone.setError("Phone should be 10 digits");
            phone.requestFocus();
        }else if(TextUtils.isEmpty(pass)){
            password.setError("Secure your account with a password");
            password.requestFocus();
        }
        else if(password.length()<5){
            password.setError("Create a password of at least 5 characters");
            password.requestFocus();
        }else if(TextUtils.isEmpty(cPass)) {
            cPassword.setError("Let's confirm you entered correctly");
            cPassword.requestFocus();
        }else if(!pass.equals(cPass)){
            password.setError("Passwords mismatched");
            password.requestFocus();
            password.setText("");
            cPassword.setText("");
        }else {

            progressBar.setVisibility(View.VISIBLE);
            StringRequest stringRequest=new StringRequest(Request.Method.POST, URLRegister, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    progressBar.setVisibility(View.GONE);

                    Toast.makeText(Registration.this, response, Toast.LENGTH_LONG).show();

                    if(response.equals("Success! Registration was successful")){
                        startActivity(new Intent(Registration.this, Login.class));
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(Registration.this,"An error occurred, please try again", Toast.LENGTH_LONG).show();
                }
            }){


                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    final String username=name.getText().toString().trim();
                    final String phoneNumber=phone.getText().toString().trim();
                    final String mail=email.getText().toString().trim();
                    final String pass=password.getText().toString().trim();
                    String cPass=cPassword.getText().toString().trim();
                    Map<String,String> params=new HashMap<>();
                    params.put("username",username);
                    params.put("email",mail);
                    params.put("phone",phoneNumber);
                    params.put("password",pass);

                    return  params;
                }
            };

            Volley.newRequestQueue(Registration.this).add(stringRequest);
        }
    }
}
